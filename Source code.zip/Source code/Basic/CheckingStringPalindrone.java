class CheckingStringPalindrone{
    public static void main(String argss[])
    {
        System.out.println("Enter the String");
        
        String originalString="aba";
        String reverseString="";
        for(int i=0;i<=originalString.length()-1;i++)
        {
            System.out.println(originalString.charAt(i));
           reverseString=reverseString+originalString.charAt(i);
        }
        boolean ispalindrom=false;
        System.out.println("1 Logic ");
        for(int i=0;i<=originalString.length()/2;i++)
        {
            if(originalString.charAt(i)==originalString.charAt(originalString.length()-i-1))
            {
                ispalindrom=true;
                
            }
        }
        
        if(ispalindrom)
        {
            System.out.println("IS palindrome ");
        }


        System.out.println("2 logic");
        if(originalString.equals(reverseString))
        {
        System.out.println("String is palindrome:: "+reverseString);
        }
        else
        {
            System.out.println("String is not palindrome "+reverseString);
        
        }
    }
}