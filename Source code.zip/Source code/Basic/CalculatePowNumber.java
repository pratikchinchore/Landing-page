class CalculatePowNumber{
    public static void main(String args[])
    {
        System.out.println("Enter the number");
        int baseNumber=3;
        int powNumber=4;
        int i=1;
        int total=1;
        while(i<=powNumber)
        {
            total=total*baseNumber;
        i++;
        }
        System.out.println("total::"+total);
    }
}