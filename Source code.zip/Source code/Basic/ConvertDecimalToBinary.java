import java.util.*;

class ConvertDecimalToBinary{
   public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter a decimal number: ");
        int decimal = sc.nextInt();
        
        int number = decimal;
        String binary = "";
        System.out.print(binary+":::");
        // Special case for 0
        if (number == 0) {
            binary = "0";
        }
        
        // Divide number by 2 repeatedly and collect remainders
        while (number > 0) {
            int remainder = number % 2;
            binary = remainder + binary; // Prepend remainder
            System.out.print(binary+",");
            number = number / 2;
        }
        
        System.out.println("Binary representation of " + decimal + " is: " + binary);
        
        sc.close();
    }
}