package ExceptionHandling;
//4. Accept an integer input from the user. If the user enters a non-integer, handle the exception using InputMismatchException.

import java.util.Scanner;

public class CustomInputMismatchMSG {

    public static void checkingInputMismatch(String name) {
        
        Scanner scn=new Scanner(System.in);

     try {
        int temp=scn.nextInt();
    
     } catch (Exception e) {
        System.err.println("input mismamtch error");
        e.printStackTrace(); 
      // TODO: handle exception
     } }
    public static void main(String[] args) {
        String name="Nikhil";
        checkingInputMismatch(name);
    }
    
}
