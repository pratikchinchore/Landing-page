package ExceptionHandling;

class ThrowThrowsExample {

    // Method declares it may throw Exception (throws)
    public static void riskyMethod() throws Exception {
        System.out.println("Inside riskyMethod");

        // Actually throwing an exception (throw)
   throw new Exception("Something went wrong!");

        // This line will NOT execute because of the throw above
        // System.out.println("This won't be printed");
    }

    public static void main(String[] args) {
        try {
            riskyMethod();  // Call method that throws exception
        } catch (Exception e) {
            System.out.println("Caught exception: " + e.getMessage());
        }

        System.out.println("Program continues after handling exception.");
    }
}

      github ->  account xyz      first stage   
      repositry(folder)->project->develpment  -> uat -> production
       
