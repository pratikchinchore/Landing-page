package ExceptionHandling;
//Create a custom exception InvalidPasswordException that is thrown when a password is too short.
class PasswordMistchException extends Exception
{
    public PasswordMistchException(String Message){
        super(Message);
    }
}
public class CustomPasswordMistchException  {

     public static void checkingPassword(String pwd)throws PasswordMistchException{
        
        if(pwd.length()<=9)
        {
            throw new PasswordMistchException("Password is too short! Must be more than 4 characters.");
        }

     }

    public static void main(String[] args) {
        
        String userPwd="XDBS@123";
try {
        checkingPassword(userPwd);
    

} catch (PasswordMistchException e) {
    e.printStackTrace();// TODO: handle exception
}
        
    }
}
