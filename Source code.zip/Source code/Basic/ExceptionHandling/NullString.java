package ExceptionHandling;
import java.util.Scanner;

public class NullString {

    // Static field
    static String nullValue;

    // Non-static field
    String nonStaticNullValue;

    // Method to access strings and handle NullPointerException
    public static void accessTheString(String temp) {
        System.out.println("-------Accessing the length--------");
        
        // Check length of the passed value safely
        try {
            System.out.println("Access the length of passed value var: " + temp.length());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: The passed value is null.");
        }
        
        // Handle Static nullValue
        System.out.println("-----------------------------");
        try {
            System.out.println("Access the length of static class-level variable: " + nullValue.length());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: Static nullValue is not initialized.");
        }

        // Handle Non-static nullValue
        NullString ns = new NullString(); // Create an instance to access non-static fields
        System.out.println("-----------------------------");
        try {
            System.out.println("Access the length of non-static class-level variable: " + ns.nonStaticNullValue.length());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: Non-static nullValue is not initialized.");
        }

        // Handle Static nullValue again
        System.out.println("-----------------------------");
        try {
            System.out.println("Access the length of static class-level variable (via instance): " + ns.nullValue.length());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: Static nullValue is still not initialized.");
        }
    }

    public static void main(String[] args) {
        // Initialize Scanner for user input
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter the name:");
        
        // Get the user input
        String name = scn.nextLine();
        
        // Call the method to access and handle strings
        accessTheString(name);
        
        // Close the scanner resource (good practice)
        scn.close();
    }
}
