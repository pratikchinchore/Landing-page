package ExceptionHandling;

 class InvalidAgeException extends Exception {

     public InvalidAgeException(String Message){
        super(Message);
     }
}

public class CustomException {
    
    public static void checkAge(int age)throws InvalidAgeException {
        if(age<18)
    {
        //    throw new InvalidAgeException("Invalid age: Must be 18 or older.");
        System.out.println("inavliud age ");
    }
    else{
        System.out.println("valid age ");
    }
    }
    public static void main(String[] args) {
        try {
        checkAge(3);    
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e);
            
        }
        
    }
    
}
