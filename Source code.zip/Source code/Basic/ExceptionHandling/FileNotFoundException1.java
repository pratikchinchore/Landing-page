package ExceptionHandling;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileNotFoundException1 {
    public static void main(String[] args) {
        // Provide the path to the file
        String filePath = "D:\\demo\\Pract\\Java Pract\\Source code\\Basic\\ExceptionHandling\\sql.txt";  // Update this with the correct file path

        FileReader reader = null;

        try {
            System.out.println("Opening the file...");

            // Open the file
            reader = new FileReader(filePath);
            System.out.println("File opened successfully.");
            System.out.println("Reading file content:\n");
BufferedReader bR = new BufferedReader(new FileReader(filePath));
            // Read the file character by character
            String character;
            while ((character = bR.readLine()) != null) {
                System.out.print( character); // cast int to char and print
            }

            System.out.println("\n\nFile reading completed.");

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
            e.printStackTrace();

        } catch (IOException e) {
            System.out.println("An I/O error occurred while reading the file.");
            e.printStackTrace();

        } finally {
            try {
                if (reader != null) {
                    reader.close();
                    System.out.println("File closed successfully.");
                }
            } catch (IOException e) {
                System.out.println("Error while closing the file.");
                e.printStackTrace();
            }

            System.out.println("End of file operations.");
        }
    }
}
