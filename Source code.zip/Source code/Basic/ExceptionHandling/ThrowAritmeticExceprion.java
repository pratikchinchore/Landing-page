package ExceptionHandling;

public class ThrowAritmeticExceprion {

    public static void CheckAge(int age){
     if(age<18)
     {
     
        System.out.println("age is "+age);
        throw new ArithmeticException("please enter age greater than so "+age);
     }
     
    }
     public static void main(String[] args) {
        int age=3;
        try {
            
            CheckAge(age);
    
        } catch (ArithmeticException e) {
             e.printStackTrace();
             System.out.println(e);
            // TODO: handle exception
        }     }
}
