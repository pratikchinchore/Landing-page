package ExceptionHandling;
//2. Create a program to access an array with an invalid index and handle ArrayIndexOutOfBoundsException.

public class ArrayIndexOut {

    // Method to fetch array elements
    public static void fethElements(int arr[]) {
        System.out.println("---------Elements Are------");
        try {
            // Loop to print array elements
            for (int i = 0; i <= arr.length; i++) {  // Correct the loop to i < arr.length
                System.out.print(", " + arr[i]);
            }
        } catch (Exception e) {
            // Handle any exceptions (ArrayIndexOutOfBoundsException in this case)
            System.out.println();
            System.out.println("Exception: " + e.getMessage());  // Prints the default exception message
            System.out.println("Custom Message: Index is out of bounds. Continuing with rest of the code.");
        }
    }

    // Method to find odd elements in the array
    public static void FindOddElements(int arr[]) {
        System.out.println("\n----Odd Elements are-------");
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % 2 != 0) {  // Check if the element is odd
                System.out.println(arr[i]);
            }
        }
    }

    public static void main(String[] args) {
        
        int numberArray[] = {1, 3, 3, 4, 5, 67, 5, 6, 65, 3, 4, 23, 43, 2};
        System.out.println("Length of the Array: " + numberArray.length);

        // Call methods
        fethElements(numberArray);
        FindOddElements(numberArray);
    }
}
