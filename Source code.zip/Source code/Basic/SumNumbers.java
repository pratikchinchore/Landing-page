import java.util.*;
class SumNumbers{
    public static void main(String[] args)
    {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Starting number");
        int StartingNumber=scn.nextInt();
        System.out.println("Enther the last number you wanted to end Sum");
        int LastNumber=scn.nextInt();
        int totalSum=0;
        int i=StartingNumber;
        do{
       
        totalSum=totalSum+i;
        i++;  
        }
        while(i<=LastNumber);
       System.out.println("Total sum is"+totalSum);
    }
}