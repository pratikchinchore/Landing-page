import java.util.*;
class PalindriomeSeries{

    public static void main(String[] args)
    {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Starting number");
        int StartingNumber=scn.nextInt();
        System.out.println("Enther the last number");
        int LastNumber=scn.nextInt();
        int c=0;
        for(int i=StartingNumber;i<=LastNumber;i++)
        {
            int temproryVar=i;
            int rev=0;
            while(temproryVar!=0)
            {
                int digit=temproryVar%10;
                rev=rev*10+digit;
                temproryVar=temproryVar/10;

            }
            if(i==rev)
        {
            System.out.println("::"+i);

            c++;
        }

        } 
      System.out.println("count of all palinfrome"+c);
    }
}