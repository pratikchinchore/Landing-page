import java.util.*;
class CheckPrimeNumber{

    public static void main(String []args)
    {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number ");

        int inputNumber=scn.nextInt();
        
        
        for(int j=1;j<=50;j++)
         {int c=0;
        for(int i=1;i<=j;i++)
        {
            if(j%i==0)
            {
                c++;
            }

        }
        //System.out.println("count"+c);
        if(c==2)
        {
            System.out.println("number is prime "+j);
        }
         }
    }
}