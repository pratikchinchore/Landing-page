class CheckPerfectNumber{

public static void main(String args[])
{
            int num=6;
            int totalSum=0;
            for (int i = 1; i <= num / 2; i++) {
            if (num % i == 0) {
                totalSum = totalSum + i;
            }
        }

        if (totalSum == num) {
            System.out.println(num + " is a perfect number.");
        } else {
            System.out.println(num + " is not a perfect number.");
        }
}

}