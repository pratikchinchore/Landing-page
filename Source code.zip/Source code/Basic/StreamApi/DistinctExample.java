package StreamApi;

import java.util.List;

public class DistinctExample {
     public static void run() {
        List<Integer> numbers = List.of(1, 2, 2, 3, 3, 4);

        numbers.stream()
               .distinct()
               .forEach(System.out::println);  // 1 2 3 4
    }
}
