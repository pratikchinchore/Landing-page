package StreamApi;

import java.util.*;

class Employee implements Comparable<Employee> {
    String name;
    int salary;

    public Employee(String name, int salary) {
        this.name = name;
        this.salary = salary;
    }

    @Override
    public int compareTo(Employee other) {
        System.out.println(this.name + ".compareTo(" + other.name + ")");
        return Integer.compare(this.salary, other.salary);
    }

    @Override
    public String toString() {
        return name + "::::: " + salary;
    }
}

public class SimpleSortTrace {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>(List.of(
            new Employee("Alice", 50000),
            new Employee("Bob", 30000),
            new Employee("Charlie", 40000)
        ));

        // We'll use a simple Bubble Sort to illustrate comparisons step-by-step
        bubbleSort(employees);

        System.out.println("Sorted list: " + employees);
    }

    // Bubble sort: repeatedly swap adjacent elements if out of order
    public static void bubbleSort(List<Employee> list) {
        int n = list.size();
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-1; j++) {
                Employee e1 = list.get(j);
                Employee e2 = list.get(j+1);
                 System.out.println("Employee e1:"+e1+", Employee e2:"+e2);
                // Compare adjacent employees
                if (e1.compareTo(e2) > 0) {
                    // Swap if e1 should come after e2
                    System.out.println("Swapping " + e1.name + " and " + e2.name);
                    System.out.println(j+","+ j+1);
                    Collections.swap(list, j, j+1);
                }
                else{
                    System.out.println("cancel");
                }
            }
        }
    }
}

