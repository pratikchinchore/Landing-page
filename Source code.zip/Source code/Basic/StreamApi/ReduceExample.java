package StreamApi;

import java.util.List;

public class ReduceExample {
      public static void run() {
        List<Integer> numbers = List.of(1, 2, 3, 4, 5);

        // Sum using reduce
        int sum = numbers.stream()
                         .reduce(0, Integer::sum);
        System.out.println("Sum = " + sum);  // 15

        // Find product
        int product = numbers.stream()
                             .reduce(1, (a, b) -> a * b);
        System.out.println("Product = " + product);  // 120

        // Find max value
        int max = numbers.stream()
                         .reduce(Integer::max)
                         .orElse(-1);
        System.out.println("Max = " + max);  // 5

        // Concatenate strings using reduce
        List<String> letters = List.of("A", "B", "C");
        String joined = letters.stream()
                               .reduce("", (a, b) -> a + b);
        System.out.println("Joined = " + joined);  // ABC
    }
}
