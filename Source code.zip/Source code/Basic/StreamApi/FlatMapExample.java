package StreamApi;

import java.util.List;
import java.util.stream.Collectors;

public class FlatMapExample {
    public static void run() {
        List<List<String>> nested = List.of(
            List.of("A", "B"),
            List.of("C", "D")
        );

        List<String> flat = nested.stream()
                                  .flatMap(List::stream)
                                  .collect(Collectors.toList());

        System.out.println(flat);  // [A, B, C, D]
    }
}
