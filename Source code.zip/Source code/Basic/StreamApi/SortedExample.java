package StreamApi;

import java.util.List;

public class SortedExample {
     public static void run() {
        List<String> fruits = List.of("Banana", "Apple", "Mango", "Grapes");

        System.out.println("Sorted in ascending order:");
        fruits.stream()
              .sorted()  // natural order (alphabetical)
              .forEach(System.out::println);

        System.out.println("\nSorted by length:");
        fruits.stream()
              .sorted((f1, f2) -> Integer.compare(f1.length(), f2.length()))
              .forEach(System.out::println);

        System.out.println("\nSorted in descending order:");
        fruits.stream()
              .sorted((a, b) -> b.compareTo(a))
              .forEach(System.out::println);
    }
}
