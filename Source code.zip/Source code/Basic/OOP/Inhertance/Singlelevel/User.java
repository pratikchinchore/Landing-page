package OOP.Inhertance.Singlelevel;

public class User {
     private String username;
    private String password;

    // Setters with basic validation
    public void setUsername(String username) {
        if (username != null && username.length() >= 6) {
            this.username = username;
        } else {
            System.out.println("Invalid username (min 6 chars).");
        }
    }

    public void setPassword(String password) {
        if (password != null && password.length() >= 6 &&
            password.matches(".*[a-zA-Z].*") && password.matches(".*\\d.*")) {
            this.password = password;
        } else {
            System.out.println("Invalid password (min 6 chars, letters & digits).");
        }
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
