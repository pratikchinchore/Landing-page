package OOP.Accsess_Modifiers;
import OOP.Accsess_Modifiers.AccessMofiersClass;
public class MainClassOfAccessing {

    
public static void main(String args[])
{
    AccessMofiersClass amc=new AccessMofiersClass();
     
    System.out.println("Accesed the (protected) var from another class in another class file within same package::"+amc.name);

    System.out.println("Accesed the (public) var from another class in another class file within same package::"+amc.address);  //can access public everywhere within same and outside the package . 
     System.out.println("Accesed the (Default) var from withinthe same class acces through another class file and same package::"+amc.price);
}

}
