package OOP.Encapsulation.BankManagemnetSYstem;
import OOP.Encapsulation.BankManagemnetSYstem.Model;
import java.util.Scanner;

public class Main {
    
    public static  void main(String []args)
    {
        System.out.println("deposit the amount");
        Scanner scn=new Scanner(System.in);
        double balance=scn.nextDouble();

        Model m=new Model();
        
        m.setBalance(balance);
        System.out.println(m.getBalance());

        System.out.println("Enter the amnt to withdraw::");
        double withDrawAmnt=scn.nextDouble();
        m.withDrawBalance(withDrawAmnt);
        System.out.println("balance is::"+m.getBalance());
        scn.close();
    }
}
