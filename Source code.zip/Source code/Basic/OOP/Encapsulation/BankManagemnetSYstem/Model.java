package OOP.Encapsulation.BankManagemnetSYstem;

public class Model {
    private double balance;

    public void setBalance(double balance)
    {
        this.balance=+balance;
    }
    public double getBalance(){
        return balance;
    }
    public double withDrawBalance(double withDrawAmnt){
        return balance=-balance-withDrawAmnt;
       
    }

}
