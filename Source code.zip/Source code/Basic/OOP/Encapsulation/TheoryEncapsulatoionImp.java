package OOP.Encapsulation;

/* 

private members (variables/methods) can be accessed only inside the class where they are declared.

Outside classes cannot directly access those variables.

So yes, this will give an error:

Student s = new Student();
s.name = "Ravi";  // ❌ ERROR: name has private access

Through public methods inside the same class — this is where getters and setters come in.

You don’t access the variable directly — you access it through a public method that lives inside the class where the private variable exists.

This is exactly what Encapsulation means:

Hide the data, expose only controlled access.private members (variables/methods) can be accessed only inside the class where they are declared.

Outside classes cannot directly access those variables.

So yes, this will give an error:

Student s = new Student();
s.name = "Ravi";  // ❌ ERROR: name has private access

Through public methods inside the same class — this is where getters and setters come in.

You don’t access the variable directly — you access it through a public method that lives inside the class where the private variable exists.

This is exactly what Encapsulation means:
Hide the data, expose only controlled access.
   This is a multi-line comment.
   You can write multiple lines here.
   It will be ignored by the compiler.
*/
public class TheoryEncapsulatoionImp {
    
    private int Rollno=21;
    private String Name;

    public void setName(String ParaName){
        this.Name=ParaName;
    }
    public int getrollno(){
        return Rollno;
    }

     public String getName(){
        return Name;
     }
    
}
