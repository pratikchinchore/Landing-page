package OOP.Encapsulation.StudentInfoManagement;

public class Model {
   private String name;
   private int age ;
   private int marks;

   public void setName(String name){
    this.name=name;
   }

   public String getName(){

    return name;
   }

   public void setAge(int age )
   {
    this.age=age;
   }
   public int getAge()
   {
     return age;
   }

   public void setMarks(int marks){
    this.marks=marks;
   }
   public int getMarks()
   {
    return marks;
   }



    
}
