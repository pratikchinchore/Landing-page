package OOP.Encapsulation.LoginCredtentials;

public class Model {
    private String userName;
    private String passWord;

 public void setUsername(String username) {
        if (username != null && username.length() >= 6) {
            this.userName = username;
        } else {
            System.out.println("Invalid username. It must be at least 6 characters long.");
        }
    }

    // Password must be at least 6 characters, include letters and numbers (basic check)
    public void setPassword(String password) {
        if (password != null && password.length() >= 6 && password.matches(".*[a-zA-Z].*") && password.matches(".*\\d.*")) {
            this.passWord = password;
        } else {
            System.out.println("Invalid password. It must be at least 6 characters long and contain both letters and numbers.");
        }
    }



    public String getUsername(){
       
        if(userName==null)
        {
            System.out.println("invalid details");
            return userName;
        }
        else{
            return userName;
        }
    }

    public String getPassWord(){
        return passWord;
    }
    

      public boolean validateLogin(String username, String password) {
        return this.userName != null && this.passWord != null &&
               this.userName.equals(username) && this.passWord.equals(password);
    }
}
