class CheckingStringContainsDigit
{

    public static void main(String args[])
    {
        String str1="123hel5675lo";

        System.out.println(str1);
        int c=0;
        for(int i=0;i<=str1.length()-1;i++)
        {
            if(str1.charAt(i)>65 && str1.charAt(i)<122)
            {
               c++;
            }
            else{
                System.out.println(str1.charAt(i));
            }
        }       

        if(str1.length()==c)
        {
            System.out.println("String does not conatin number");
        }
        else{
            System.out.println("string contain numbers");
        }

    }
}