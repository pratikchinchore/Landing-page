package Mulithreading;
class SharedResource {
    public synchronized void waitForSignal() throws InterruptedException {
        System.out.println(Thread.currentThread().getName() + " is waiting");
        wait();  // Releases lock and waits
        System.out.println(Thread.currentThread().getName() + " resumed after notify");
    }

    public synchronized void sendSignal() {
        System.out.println(Thread.currentThread().getName() + " is sending notify");
        notify();  // Wakes up waiting thread
    }
}

public class WaitNotifyExample {
    public static void main(String[] args) throws InterruptedException {

        SharedResource resource = new SharedResource();

        Thread waitingThread = new Thread(() -> {
            try {
                resource.waitForSignal();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }, "WaitingThread");

        Thread notifyingThread = new Thread(() -> {
            try {
                Thread.sleep(2000);  // wait before notifying
                resource.sendSignal();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }, "NotifyingThread");

        waitingThread.start();
        notifyingThread.start();

     //   waitingThread.join();
     //   notifyingThread.join();
    }
}
