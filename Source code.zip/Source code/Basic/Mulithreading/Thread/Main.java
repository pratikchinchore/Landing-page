package Mulithreading.Thread;

// Thread subclass with its own count variable
class TaskThread extends Thread {
    private int count = 0;

    public TaskThread(String name) {
        super(name);  // Set thread name
    }

    public void run() {
        for (int i = 0; i < 5; i++) {
            count++;
            System.out.println(getName() + " - Count: " + count);
            try {
                Thread.sleep(100); // simulate some work
            } catch (InterruptedException e) {
                System.out.println("Thread interrupted");
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        TaskThread t1 = new TaskThread("Thread-1");
        TaskThread t2 = new TaskThread("Thread-2");

        t1.start();
        t2.start();
    }
}
