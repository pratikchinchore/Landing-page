package Mulithreading.Runnableinterface;

// Runnable task that will be shared by multiple threads
class SharedTask implements Runnable {
    private int count = 0;

    public void run() {
        for (int i = 0; i < 5; i++) {
            count++;
            System.out.println(Thread.currentThread().getName() + " - Count: " + count);
            try {
                Thread.sleep(100); // simulate some work
            } catch (InterruptedException e) {
                System.out.println("Thread interrupted");
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        SharedTask task = new SharedTask(); // single Runnable instance

        // Create multiple threads sharing the same Runnable object
        Thread t1 = new Thread(task, "Thread-1");
        Thread t2 = new Thread(task, "Thread-2");

        t1.start();
        t2.start();
    }
}
