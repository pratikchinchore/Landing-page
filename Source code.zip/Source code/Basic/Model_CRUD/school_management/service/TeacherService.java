package Model_CRUD.school_management.service;

import Model_CRUD.school_management.model.Teacher;

import java.util.ArrayList;
import java.util.List;

public class TeacherService {
    private List<Teacher> teachers = new ArrayList<>();

    public void addTeacher(Teacher teacher) {
        teachers.add(teacher);
    }

    public Teacher getTeacherById(int id) {
        return teachers.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public boolean updateTeacher(int id, String newName) {
        Teacher teacher = getTeacherById(id);
        if (teacher != null) {
            teacher.setName(newName);
            return true;
        }
        return false;
    }

    public boolean deleteTeacher(int id) {
        return teachers.removeIf(t -> t.getId() == id);
    }

    public void displayAllTeachers() {
        if (teachers.isEmpty()) {
            System.out.println("No teachers found.");
        } else {
            teachers.forEach(System.out::println);
        }
    }
}
