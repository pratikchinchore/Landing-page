package Model_CRUD.school_management.service;

import Model_CRUD.school_management.model.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentService {
    private List<Student> students = new ArrayList<>();

    // Create - Add student
    public void addStudent(Student student) {
        students.add(student);
    }

    // Read - Get student by ID
    public Student getStudentById(int id) {
        return students.stream()
                .filter(s -> s.getId() == id)
                .findFirst()
                .orElse(null);
    }

    // Update - Update student info
    public boolean updateStudent(int id, String newName, String newGrade) {
        Student student = getStudentById(id);
        if (student != null) {
            student.setName(newName);
            student.setGrade(newGrade);
            return true;
        }
        return false;
    }

    // Delete - Remove student
    public boolean deleteStudent(int id) {
        return students.removeIf(s -> s.getId() == id);
    }

    // Display all students
    public void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            students.forEach(System.out::println);
        }
    }
}

