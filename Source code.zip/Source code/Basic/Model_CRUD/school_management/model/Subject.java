package Model_CRUD.school_management.model;



public class Subject {
    private String name;
    private String teacherName;

    public Subject(String name, String teacherName) {
        this.name = name;
        this.teacherName = teacherName;
    }

    // getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }

    @Override
    public String toString() {
        return name + " (Teacher: " + teacherName + ")";
    }
}
