package Model_CRUD.healthcare_management.service;




import Model_CRUD.healthcare_management.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class PatientService {
    private List<Patient> patients = new ArrayList<>();

    public void addPatient(Patient patient) {
        patients.add(patient);
    }

    public Patient getPatientById(int id) {
        for (Patient p : patients) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    public boolean updatePatient(int id, String newName, int newAge, String newIllness) {
        Patient patient = getPatientById(id);
        if (patient != null) {
            patient.setName(newName);
            patient.setAge(newAge);
            patient.setIllness(newIllness);
            return true;
        }
        return false;
    }

    public boolean deletePatient(int id) {
        return patients.removeIf(p -> p.getId() == id);
    }

    public void displayAll() {
        for (Patient p : patients) {
            System.out.println(p);
        }
    }
}
