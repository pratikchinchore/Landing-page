class FindNextPalindrome
{
    public static int getNextPalindrome(int num)
    {
        num++;

       for(int i=num;;i++)
       {
        int rev=0; 
        int temp=i;
       while(temp!=0)
       {
        int digit=temp%10;
         rev=rev*10+digit;
        temp=temp/10;
       }
       if(rev==i)
       {
       System.out.println(rev);
         return rev;
       }   
    }

     //   return num;
    }

    public static void main(String args[])
    {
        int number=22;
        System.out.print("searching using recursion.......");
        int NextPalindromeNumber=FindNextPalindrome.getNextPalindrome(number);

        System.out.println(NextPalindromeNumber);
    }
}