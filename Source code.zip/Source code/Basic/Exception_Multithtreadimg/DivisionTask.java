package Exception_Multithtreadimg;
// Create a program that starts 3 threads. Each thread divides two numbers (numerator and denominator), and the input values are hardcoded.
// Use exception handling to catch any division by zero errors.


// TaskPerformer implements Runnable to separate task from Thread management
class TaskPerformer implements Runnable {
    private int num;
    private String threadName;

    // Constructor to set numerator and thread name
    public TaskPerformer(int num, String threadName) {
        this.num = num;
        this.threadName = threadName;
    }

    @Override
    public void run() {
        System.out.println(threadName + " started.");
        try {
            for (int i = 1; i <= 5; i++) {
                // Intentionally cause division by zero when i=0 is avoided
                int divisionTotal =  i / num;
                System.out.println(threadName + ": " + num + " / " + i + " = " + divisionTotal);
                Thread.sleep(300);  // Simulate some delay
            }
        } catch (ArithmeticException e) {
            // This will catch division by zero errors (if any)
            System.out.println(threadName + " caught ArithmeticException: " + e.getMessage());
        } catch (InterruptedException e) {
            // Handle thread interruption
            System.out.println(threadName + " was interrupted.");
        } catch (Exception e) {
            // Catch any other unexpected exceptions
            System.out.println(threadName + " encountered an error: " + e.getMessage());
        } finally {
            System.out.println(threadName + " finished.\n");
        }
    }
}

public class DivisionTask {
    public static void main(String[] args) {
        System.out.println("Starting division tasks...\n");

        // Create 3 threads with different numerators and names
        Thread t1 = new Thread(new TaskPerformer(10, "Thread-1"));
        Thread t2 = new Thread(new TaskPerformer(0, "Thread-2"));  // numerator zero is valid, denominator never zero here
        Thread t3 = new Thread(new TaskPerformer(20, "Thread-3"));

        // Start the threads
        t1.start();
        t2.start();
        t3.start();

        // Optionally wait for threads to finish
        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }

        System.out.println("All threads finished.");
    }
}
