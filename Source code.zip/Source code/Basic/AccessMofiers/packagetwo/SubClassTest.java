package AccessMofiers.packagetwo;
import AccessMofiers.packageone.DemoClass;
public class SubClassTest {
     public void testAccess() {
        System.out.println(publicVar);          // ✅ accessible (inherited)
        // System.out.println(privateVar);      // ❌ not accessible
        System.out.println(protectedVar);       // ✅ accessible (inherited)
        // System.out.println(defaultVar);      // ❌ not accessible

        publicMethod();                         // ✅ accessible
        // privateMethod();                     // ❌ not accessible
        protectedMethod();                      // ✅ accessible
        // defaultMethod();                     // ❌ not accessible

        System.out.println(publicStaticVar);   // ✅ accessible
        // System.out.println(privateStaticVar);// ❌ not accessible
        System.out.println(protectedStaticVar);// ✅ accessible
        // System.out.println(defaultStaticVar);// ❌ not accessible

        publicStaticMethod();                   // ✅ accessible
        // privateStaticMethod();               // ❌ not accessible
        protectedStaticMethod();                // ✅ accessible
        // defaultStaticMethod();               // ❌ not accessible
    }
}
