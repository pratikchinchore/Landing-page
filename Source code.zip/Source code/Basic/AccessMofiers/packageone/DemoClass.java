   package AccessMofiers.packageone;

public class DemoClass {
    public int publicVar = 1;
    private int privateVar = 2;
    protected int protectedVar = 3;
    int defaultVar = 4;  // default

    public static int publicStaticVar = 10;
    private static int privateStaticVar = 20;
    protected static int protectedStaticVar = 30;
    static int defaultStaticVar = 40;

    public void publicMethod() { System.out.println("Public method"); }
    private void privateMethod() { System.out.println("Private method"); }
    protected void protectedMethod() { System.out.println("Protected method"); }
    void defaultMethod() { System.out.println("Default method"); }

    public static void publicStaticMethod() { System.out.println("Public static method"); }
    private static void privateStaticMethod() { System.out.println("Private static method"); }
    protected static void protectedStaticMethod() { System.out.println("Protected static method"); }
    static void defaultStaticMethod() { System.out.println("Default static method"); }
}

   
   public class DemoClass {
    public int publicVar = 1;
    private int privateVar = 2;
    protected int protectedVar = 3;
    int defaultVar = 4;  // default

    public static int publicStaticVar = 10;
    private static int privateStaticVar = 20;
    protected static int protectedStaticVar = 30;
    static int defaultStaticVar = 40;

    public void publicMethod() { System.out.println("Public method"); }
    private void privateMethod() { System.out.println("Private method"); }
    protected void protectedMethod() { System.out.println("Protected method"); }
    void defaultMethod() { System.out.println("Default method"); }

    public static void publicStaticMethod() { System.out.println("Public static method"); }
    private static void privateStaticMethod() { System.out.println("Private static method"); }
    protected static void protectedStaticMethod() { System.out.println("Protected static method"); }
    static void defaultStaticMethod() { System.out.println("Default static method"); }
}