package AccessMofiers.ProtectedInfo.packagetwo;

import AccessMofiers.ProtectedInfo.packageone.BaseClass;

public class NonSubClass {
      public void accessProtected() {
        BaseClass obj = new BaseClass();
   //   System.out.println(obj.message);     //❌ Not allowed
        // obj.showMessage();                ❌ Not allowed
    }
}
