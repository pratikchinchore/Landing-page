package AccessMofiers.ProtectedInfo.packagetwo;

import AccessMofiers.ProtectedInfo.packageone.BaseClass;
public class SubClass extends BaseClass {   //need to extend 
    public void accessProtected() {
        System.out.println(this.message);   // ✅ Accessible (inherited)
        this.showMessage();                 // ✅ Accessible
    }
}
