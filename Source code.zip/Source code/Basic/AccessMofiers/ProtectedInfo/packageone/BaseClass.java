package AccessMofiers.ProtectedInfo.packageone;

public class BaseClass {
    protected String message = "Hello from protected";

    protected void showMessage() {
        System.out.println(message);
    }
}
