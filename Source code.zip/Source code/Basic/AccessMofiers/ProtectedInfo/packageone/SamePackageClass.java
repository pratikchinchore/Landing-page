package AccessMofiers.ProtectedInfo.packageone;

public class SamePackageClass {
      public void accessProtected() {
        BaseClass obj = new BaseClass();
        System.out.println(obj.message);  // ✅ Accessible
        obj.showMessage();                // ✅ Accessible
    }
    
}
