package Pattern.NumberPattern;

public class NPattern3 {
    public static void main(String[] args)
    {
        int incrementNumb=1;
       for(int i=1;i<=5;i++)
       {
        for(int j=1;j<=i;j++)
        {
            System.out.print(" "+incrementNumb);
        incrementNumb++;
        }
        
   System.out.println("");
    
       }
    }
}
