package Pattern.NumberPattern;

class NPattern6{
    
        public static void main(String []args)
        {
           int n = 5;

        for (int i = 1; i <= n; i++) {
            // Print leading spaces to center-align
            for (int s = 1; s <= n - i; s++) {
                System.out.print(" ");
            }

            // Print decreasing numbers from 5 to (5 - i + 1)
            for (int j = n; j >= n - i + 1; j--) {
                System.out.print(j);
            }

            // Print increasing numbers from (5 - i + 2) to 5
            for (int j = n - i + 2; j <= n; j++) {
                System.out.print(j);
            }

            System.out.println();
        }
}
}
