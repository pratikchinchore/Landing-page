package Pattern;
class SPattern3{
    public static void main(String args[])
    { int s=10;  //0-10= 10
                 //1-10
        for(int i=0;i<=10;i++)
        {
           
            for(int j=0;j<=10;j++)
            {
                if(j==i||j==(10-i))
                {
                    System.out.print("*");
                }
                else
                {
                    System.out.print(" ");
                }
            }
            s--;
            System.out.println();
        }
    }
}