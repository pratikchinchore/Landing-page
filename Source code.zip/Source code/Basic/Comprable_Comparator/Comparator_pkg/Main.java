package Comprable_Comparator.Comparator_pkg;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        students.add(new Student("Alice", 22));
        students.add(new Student("Bob", 20));
        students.add(new Student("Charlie", 25));
        students.add(new Student("David", 22));

        System.out.println("🔹 Original list:");
        students.forEach(System.out::println);

        System.out.println("\n🔹 Sorted by age (ascending):");
        Collections.sort(students, new AgeComparator());
        students.forEach(System.out::println);

        System.out.println("\n🔹 Sorted by name (A → Z):");
        Collections.sort(students, new NameComparator());
        students.forEach(System.out::println);

        System.out.println("\n🔹 Sorted by name length:");
        Collections.sort(students, new NameLengthComparator());
        students.forEach(System.out::println);

        System.out.println("\n🔹 Sorted by age (descending):");
        Collections.sort(students, new AgeDescendingComparator());
        students.forEach(System.out::println);
    }
}
