package Comprable_Comparator.Comparator_pkg;

import java.util.Comparator;

public class NameLengthComparator implements Comparator<Student> {
    @Override
    public int compare(Student s1, Student s2) {
        return s1.name.length() - s2.name.length();
    }
}
