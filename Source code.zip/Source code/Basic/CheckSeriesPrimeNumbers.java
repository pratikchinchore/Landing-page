    class CheckSeriesPrimeNumbers{

        public static void main(String args[])
        {
            int StartNumber=1;
            int LastNumber=42;
            
        
            for(int i=StartNumber;i<=LastNumber;i++)
            { int c=0;
                for(int j=1;j<=i;j++)
                {
                    if(i%j==0)
                    {
                        c++;
                    }
                }
                
                if(c==2)
                {
                    System.out.print(" :"+i);
                }
            }
        }
    }