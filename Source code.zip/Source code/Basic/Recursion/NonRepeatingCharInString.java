package Recursion;

class NonRepeatingCharInString {
    public static void main(String args[]) {
        String charactersString = "ewr123abaecdda";
        boolean firstRepeatChar=false;
       for(int i=0;i<=charactersString.length()-1;i++)
       {
          
          for(int j=0;j<=charactersString.length()-1;j++)
          {
            if(charactersString.charAt(i)==charactersString.charAt(j)&&i!=j)
            {
              firstRepeatChar=true;
            break;
            }
          }
          if(firstRepeatChar)
          {
            System.out.println("first Charater Repeated is:::"+charactersString.charAt(i));
            break;
          }
        }
    }
}
