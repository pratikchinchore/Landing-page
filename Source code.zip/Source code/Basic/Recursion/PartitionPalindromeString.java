package Recursion;

public class PartitionPalindromeString {

    public static void main(String args[]) {
        String inputString = "forgeeksskeegfor";
        String palindromePartitions = "";

        System.out.println("Input String: " + inputString);
        System.out.println("Palindromic substrings (partitions):");

        for (int i = 0; i < inputString.length(); i++) {
            for (int j = i; j < inputString.length(); j++) {
                String substr = inputString.substring(i, j + 1);

                if (checkPalindrome(substr)) {
                    palindromePartitions += substr + ",";
                }
            }
        }

        // Remove last comma if needed
        if (palindromePartitions.endsWith(",")) {
            palindromePartitions = palindromePartitions.substring(0, palindromePartitions.length() - 1);
        }

        System.out.println(palindromePartitions);
    }

    public static boolean checkPalindrome(String str) {
        int i = 0;
        int j = str.length() - 1;

        while (i < j) {
            if (str.charAt(i) != str.charAt(j)) {
                return false;
            }
            i++;
            j--;
        }

        return true;
    }
}
