package Recursion;

class FindFirstNonReaptingChar {
    public static void main(String args[]) {
        String charactersString = "aabadcb";// 3  b
        
        for(int i=0;i<=charactersString.length()-1;i++)
        {
            
            boolean isRepeated=false;
            for(int j=0;j<i;j++)
            {
                if(charactersString.charAt(i)==charactersString.charAt(j))
                {
                  isRepeated=true;
                break;
                }
            }
            if(isRepeated)
            {
              continue;
             }
             int c=0;
             for(int s=i+1;s<=charactersString.length()-1;s++)
             {
                if(charactersString.charAt(i)==charactersString.charAt(s))
                {
                  c++;                 
                }


            }
            if(c==0)
            {
                System.out.println("First Non repeating element is ");
             
                System.out.println("::"+charactersString.charAt(i));
                break;
            }
        }
        
        
}

}

