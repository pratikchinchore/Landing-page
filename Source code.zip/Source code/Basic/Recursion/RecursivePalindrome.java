package Recursion;

public class RecursivePalindrome {
   
   public static int getRecursivePalindrome(int num,int rev) {
      
    if(num==0)
      {
        System.out.println(num+","+rev);
        return rev;
      }
      else
      {
        int digit=num%10;
          rev=rev*10+digit;
   return rev= getRecursivePalindrome(num/10,rev);
        
      }
    

}

public static boolean ispalindrome(int num){
    
return num==getRecursivePalindrome(num,0);
}
    public static void main(String args[])
    {
        System.out.println("Enter the Number::");
        int num=33;
        
        if(ispalindrome(num))
        {
            System.out.println("is palindrome");
        }
        else{

            System.out.print("IS NOT PLAINDROME");
        }
        

    }
}
