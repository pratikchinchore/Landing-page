package Recursion;

public class RecursiveFactorial {
    
   public static int getRecursiveFact(int num) {
    System.out.println("Calling getRecursiveFact(" + num + ")");
    if (num == 0 || num == 1) {
        System.out.println("Base case reached for " + num);
        return 1;
    } else {
        int result = num * getRecursiveFact(num - 1);    
        System.out.println("Returning " + result + " for getRecursiveFact(" + num + ")");
        return result;
    }
}

    public static void main(String args[])
    {
        System.out.println("Enter the Number::");
        int num=3;
        int factorialIs=getRecursiveFact(num);
        System.out.println(factorialIs);
    }
}
