class FibonaciSeries
{

   public static void main(String []args)
   {
      //n=5
      //0 1 1 2 3 5
      
      int s1=0;
      int s2=1;
      int f3=0;
         int f2=1;
         System.out.print(s1);
         System.out.print(s2);
      for(int i=2;i<5;i++)
      {
         f3=s1+s2;
         System.out.print(f3);
         s1=s2;
         s2=f3;
      }
   }

}