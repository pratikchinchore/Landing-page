import java.util.*;
class ReverseNumber{

    public static int convertingToReverse(int temproryNum)
    {
        // System.out.println();
        int rev=0;
        while(temproryNum!=0)
        {
            int digit=temproryNum%10;
            rev=rev*10+digit;
            temproryNum=temproryNum/10;
        }
        return rev;
    }
    public static void main(String [] args)
    {
        System.out.println("Enter the number ");
        Scanner scn=new Scanner(System.in);
        int originalNum=scn.nextInt();

        int reverseNumber=convertingToReverse(originalNum);
        System.out.println("Reverse Number is "+reverseNumber);

    }
}