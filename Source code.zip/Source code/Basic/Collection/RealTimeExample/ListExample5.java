package Collection.RealTimeExample;

import java.util.*;
public class ListExample5 {

    public static void main(String[] args) {
      
        List<String> class1=new ArrayList<>(Arrays.asList("k1","k2","k3","k4","k5","k6","k51"));
        
        List<String> class2=new ArrayList<>(Arrays.asList("k7","k8","k9","k4","k5","k10"));

 
        List<String> class3=new ArrayList<>();

                for (String s2 : class2) {
            for (String s1 : class1) {
                if (s2.equals(s1) && !class3.contains(s2)) {
                    System.out.println(s2 + " same in both class");
                    class3.add(s2);
                }
            }
        }

        System.out.println("Common elements: " + class3);
        

    }
}
