package Collection.RealTimeExample;

import java.util.*;
import java.util.stream.Collectors;
class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public int getAge() {
        return age;
    }
    public String getName(){
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}

public class ListExample6 {
     public static void main(String[] args) {
        List<Person> people = Arrays.asList(
            new Person("Alice", 25),
            new Person("Bob", 30),
            new Person("Charlie", 25),
            new Person("David", 30),
            new Person("Eve", 35)
        );

        // Group by Name
       // Group by Name
Map<String, List<Person>> groupedByName = people.stream()
    .collect(Collectors.groupingBy(Person::getName));

System.out.println(groupedByName.toString());  
// Print grouped result
groupedByName.forEach((name, persons) -> {
    System.out.println("Name " + name + ": " + persons);

});

Map<Integer,List<Person>> groupByAge=people.stream().collect(Collectors.groupingBy(Person::getAge));

groupByAge.forEach((age,name)->{
    System.out.println("age is "+age+" name is::"+name);
});
    }
}