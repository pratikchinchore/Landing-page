package Collection.RealTimeExample;
import java.util.*;

//2. Find Most Frequent Item in Shopping List


public class ListExample2 {
    public static void main(String[] args) {
        List<String> productName=new ArrayList<>(Arrays.asList("prdct1","prdct2","prct3","prdct4","prdct2","prct3","prdct2","prdct2"));        
        System.out.println(productName.toString());
        System.out.println("product most frequent  sell");
        for(int i = 0; i <= productName.size()-1; i++) {
            int c=0;
            for (int j = i+1; j <= productName.size()-1; j++) {
                if(productName.get(i).equals(productName.get(j))&&productName.get(i)!="null")
                {
                      productName.set(j,"null");
                    c++;
                }
            }
            if(c>0)
            {
                System.out.println(productName.get(i) +" Count is "+c);
            }
        }
         System.out.println(productName.toString());

List<String> productName2 = new ArrayList<>(Arrays.asList(
            "prdct1", "prdct2", "prct3", "prdct4", "prdct2", "prct3", "prdct2", "prdct2"
        ));


  Set<String> uniqueProducts = new HashSet<>(productName2);  // Unique items
        String mostFrequent = null;
        int maxCount = 0;

        for (String product : uniqueProducts) {
            int frequency = Collections.frequency(productName2, product);
            System.out.println(product + " Count is " + frequency);

            if (frequency > maxCount) {
                maxCount = frequency;
                mostFrequent = product;
            }
        }

        System.out.println("Most Frequently Sold Product: " + mostFrequent + " (Count: " + maxCount + ")");
       
    }
}
