package Collection.Queue;
import java.util.*;
public class QueueExample {
    public static void main(String[] args) {
        Queue<String> queue = new LinkedList<>();
        queue.add("Task 1");
        queue.add("Task 2");
        queue.add("Task 3");

        System.out.println("Queue: " + queue);  // [Task 1, Task 2, Task 3]

        // Remove elements (FIFO)
        System.out.println("Removed: " + queue.poll());  // Task 1
        System.out.println("Queue after removal: " + queue);  // [Task 2, Task 3]
    }
}
