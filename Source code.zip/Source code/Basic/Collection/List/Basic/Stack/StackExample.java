package Collection.List.Basic.Stack;

import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        // Create a Stack of Integers
        Stack<Integer> stack = new Stack<>();

        // 1. Pushing elements onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        System.out.println("Stack after pushing elements: " + stack);

        // 2. Popping elements from the stack
        System.out.println("Popped element: " + stack.pop());  // Removes and returns the top element (50)
        System.out.println("Stack after pop: " + stack);

        // 3. Peeking at the top element (without removing it)
        System.out.println("Top element: " + stack.peek());  // Returns the top element (40)

        // 4. Checking if the stack is empty
        System.out.println("Is the stack empty? " + stack.empty());  // false

        // 5. Searching for an element in the stack
        System.out.println("Position of element 20 from top: " + stack.search(20));  // 2 (2nd from top)
        System.out.println("Position of element 100 from top: " + stack.search(100));  // -1 (not found)

        // 6. Checking the size of the stack
        System.out.println("Stack size: " + stack.size());  // 3

        // 7. Pop all remaining elements
        while (!stack.empty()) {
            System.out.println("Popped: " + stack.pop());
        }
        
        // 8. Check if the stack is empty after popping all elements
        System.out.println("Is the stack empty now? " + stack.empty());  // true
    }
}
