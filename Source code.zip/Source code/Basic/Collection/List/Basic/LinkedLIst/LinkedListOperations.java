package Collection.List.Basic.LinkedLIst;

import java.util.LinkedList;
import java.util.Iterator;

public class LinkedListOperations {
    public static void main(String[] args) {
        
        // Create a LinkedList of Integer type
        LinkedList<Integer> linkedList = new LinkedList<>();

        // 1. Add elements to the LinkedList
        linkedList.add(10);  // Add to the end
        linkedList.add(20);
        linkedList.add(30);
        linkedList.add(40);

        // Print initial LinkedList
        System.out.println("Initial LinkedList: " + linkedList);
        
        // 2. Add elements at the beginning and end
        linkedList.addFirst(5);   // Adds 5 at the beginning
        linkedList.addLast(50);   // Adds 50 at the end
        
        System.out.println("After adding elements at the beginning and end: " + linkedList);

        // 3. Remove elements from the LinkedList
        linkedList.removeFirst();  // Removes 5
        linkedList.removeLast();   // Removes 50
        
        System.out.println("After removing first and last elements: " + linkedList);

        // 4. Remove an element by value
        linkedList.remove(Integer.valueOf(20));  // Removes 20
        
        System.out.println("After removing element with value 20: " + linkedList);

        // 5. Accessing elements
        System.out.println("First element: " + linkedList.getFirst());   // First element
        System.out.println("Last element: " + linkedList.getLast());     // Last element
        System.out.println("Element at index 1: " + linkedList.get(1));  // Element at index 1
        
        // 6. Check if the LinkedList contains a specific element
        System.out.println("Contains 30: " + linkedList.contains(30)); // true
        System.out.println("Contains 100: " + linkedList.contains(100)); // false

        // 7. Check size of the LinkedList
        System.out.println("Size of the LinkedList: " + linkedList.size()); // 3
        
        // 8. Iterate using Iterator
        System.out.println("Iterating through LinkedList using Iterator:");
        Iterator<Integer> iterator = linkedList.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // 9. Iterating using for-each loop
        System.out.println("Iterating through LinkedList using for-each loop:");
        for (Integer element : linkedList) {
            System.out.println(element);
        }

        // 10. Clear all elements in the LinkedList
        linkedList.clear();
        System.out.println("LinkedList after clear(): " + linkedList);
        
    }
}
