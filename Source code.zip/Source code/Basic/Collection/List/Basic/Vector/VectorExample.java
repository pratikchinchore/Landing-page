package Collection.List.Basic.Vector;
import java.util.Vector;

public class VectorExample {
    public static void main(String[] args) {
        
        // Creating a Vector
        Vector<Integer> vector = new Vector<>();
        
        // 1. Add elements to the vector
        vector.add(10);  // Adds to the end of the vector
        vector.add(20);
        vector.add(30);
        vector.add(40);
        vector.add(50);

        System.out.println("Vector after adding elements: " + vector);
        
        // 2. Add an element at a specific index
        vector.add(2, 25);  // Adds 25 at index 2
        System.out.println("After adding 25 at index 2: " + vector);

        // 3. Remove elements
        vector.remove(3);  // Removes the element at index 3 (element 40)
        System.out.println("After removing element at index 3: " + vector);
        
        // 4. Remove the first occurrence of a specific element
        vector.remove(Integer.valueOf(20));  // Removes first occurrence of 20
        System.out.println("After removing element 20: " + vector);

        // 5. Get elements
        System.out.println("Element at index 2: " + vector.get(2));  // Accessing element at index 2
        
        // 6. Check if an element exists in the vector
        System.out.println("Contains 25: " + vector.contains(25));  // true
        System.out.println("Contains 100: " + vector.contains(100)); // false
        
        // 7. Get the size of the vector
        System.out.println("Size of the vector: " + vector.size()); // Returns the number of elements
        
        // 8. Get the first and last elements
        System.out.println("First element: " + vector.firstElement());  // First element (10)
        System.out.println("Last element: " + vector.lastElement());    // Last element (50)
        
        // 9. Set an element at a specific index
        vector.set(1, 35);  // Replaces element at index 1 with 35
        System.out.println("After setting element at index 1 to 35: " + vector);
        
        // 10. Trim the capacity of the vector
        vector.trimToSize();  // Reduces the capacity to the current size (can improve memory usage)
        System.out.println("Vector after trimming the capacity: " + vector);
        
        // 11. Ensure capacity for a specified size
        vector.ensureCapacity(20);  // Ensures the vector can hold at least 20 elements
        System.out.println("Vector capacity after ensuring capacity for 20 elements: " + vector.capacity());
        
        // 12. Clear all elements
        vector.clear();  // Removes all elements
        System.out.println("Vector after clear(): " + vector);
    }
}
