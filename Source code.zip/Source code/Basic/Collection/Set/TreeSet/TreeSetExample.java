package Collection.Set.TreeSet;

import java.util.*;

public class TreeSetExample {
    public static void main(String[] args) {
        // Create a TreeSet with some initial elements
        TreeSet<Integer> treeSet = new TreeSet<>();

        // Adding elements
        treeSet.add(10);
        treeSet.add(20);
        treeSet.add(5);
        treeSet.add(15);
        treeSet.add(30);
        treeSet.add(20); // Duplicate, won't be added

        System.out.println("TreeSet: " + treeSet); // Output: [5, 10, 15, 20, 30]

        // Check if an element exists
        System.out.println("Contains 15? " + treeSet.contains(15)); // Output: true
        System.out.println("Contains 100? " + treeSet.contains(100)); // Output: false

        // Size of the TreeSet
        System.out.println("Size: " + treeSet.size()); // Output: 5

        // Remove an element
        treeSet.remove(10);
        System.out.println("After removing 10: " + treeSet); // Output: [5, 15, 20, 30]

        // First and last elements
        System.out.println("First element: " + treeSet.first()); // Output: 5
        System.out.println("Last element: " + treeSet.last()); // Output: 30

        // SubSet: elements less than 20
        SortedSet<Integer> headSet = treeSet.headSet(20);
        System.out.println("HeadSet (elements < 20): " + headSet); // Output: [5, 15]

        // TailSet: elements greater than or equal to 20
        SortedSet<Integer> tailSet = treeSet.tailSet(20);
        System.out.println("TailSet (elements >= 20): " + tailSet); // Output: [20, 30]

        // SubSet: elements between 5 and 20 (exclusive of 20)
        SortedSet<Integer> subSet = treeSet.subSet(5, 20);
        System.out.println("SubSet (elements between 5 and 20): " + subSet); // Output: [5, 15]

        // Iterating over TreeSet using iterator
        Iterator<Integer> iterator = treeSet.iterator();
        System.out.print("TreeSet elements using iterator: ");
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " "); // Output: 5 15 20 30
        }
        System.out.println();

        // Iterating using forEach method
        System.out.print("TreeSet elements using forEach: ");
        treeSet.forEach(element -> System.out.print(element + " ")); // Output: 5 15 20 30
        System.out.println();

        // Checking if the set is empty
        System.out.println("Is the TreeSet empty? " + treeSet.isEmpty()); // Output: false

        // Clear the TreeSet
        treeSet.clear();
        System.out.println("After clearing, TreeSet: " + treeSet); // Output: []
    }
}
