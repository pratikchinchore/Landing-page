//package Collection.Set.Pract_Hash;
package Collection.Set.Pract_Hash;

// import java.util.HashSet;
// import  Pract_Hash.Student;



//fist chck the ovbject same 
//then check ALL THE VALUES 
//WHat if i dont want the age to be same rest can be same

public class SetFile {
    public static void main(String[] args) {
System.out.println("************************************************");
Student s1 = new Student(1, 22, "kiran");
Student s2 = new Student(1, 30, "kiran"); // different age
Student s3 = new Student(1, 22, "kiran"); // same as s1 in values

System.out.println("s1 == s2 : " + (s1 == s2));         // false
System.out.println("s1.equals(s2): " + s1.equals(s2));  // depends on equals() implementation
System.out.println("s1.hashCode(): " + s1.hashCode());
System.out.println("s2.hashCode(): " + s2.hashCode());
System.out.println("s3.hashCode(): " + s3.hashCode());
System.out.println("s1.equals(s3): " + s1.equals(s3));

System.out.println("************************************************");
        System.out.println("Insrting the data........");
        HashSet<Student> h1=new HashSet<Student>();
        h1.add(new Student(1,22,"kiran"));
        h1.add(new Student(2,32,"narayn"));
        h1.add(new Student(3,33,"sham"));
        h1.add(new Student(1,22,"kiran"));

         System.out.println(h1);
        

    }
}
