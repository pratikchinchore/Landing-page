package Collection.Set.Pract_Hash;

import java.util.Objects;
public class Student {
    public int id;
    public int age ;
    public String name;

    public Student(int id,int age,String name){
        this.id=id;
        this.age=age;
        this.name=name;
    }
//     public String toString(){
//         return "id::"+id+" Age::"+age+" Name::"+name+"\n";
//     }
//     @Override
// public int hashCode() {
//     System.out.println("--------inside the hashCode-------");
//     int h = Objects.hash(id, name);
//     System.out.println("hashCode called: " + h);
//     System.out.println("--------finish the hashCode-------");
//     return h;
// }
   
// @Override
// public boolean equals(Object ob) {
//     System.out.println("\n-------- inside equals() --------");

//     // 1. Show input objects
//     System.out.println("this: " + this);
//     System.out.println("ob:   " + ob);

//     // 2. Check same reference
//     if (this == ob) {
//         System.out.println("Same reference. Returning true.");
//         return true;
//     }

//     // 3. Check for null or different class
//     if (ob == null) {
//         System.out.println("ob is null. Returning false.");
//         return false;
//     }

//     System.out.println("getClass() of this: " + getClass());
//     System.out.println("getClass() of ob:   " + ob.getClass());

//     if (getClass() != ob.getClass()) {
//         System.out.println("Different classes. Returning false.");
//         return false;
//     }

//     // 4. Safe to cast and compare fields
//     Student other = (Student) ob;
//     System.out.println("Comparing fields...");
//     System.out.println("this.id: " + this.id + ", other.id: " + other.id);
//     System.out.println("this.name: " + this.name + ", other.name: " + other.name);

//     boolean isEqual = this.id == other.id && Objects.equals(this.name, other.name);
//     System.out.println("Field comparison result: " + isEqual);

//     System.out.println("-------- end of equals() --------\n");
//     return isEqual;
// }

}
