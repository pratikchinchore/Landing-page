public class FindScndLargestEle {

     public static void main(String[] args) {
       int array1[] = {12, 43, 2, 45, 5, 6, 87, 98, 876};

        // Initialize with very small values
        int max = Integer.MIN_VALUE;
        int scndmax = Integer.MIN_VALUE;
        System.out.println(max);
        System.out.println(scndmax);
        for (int num : array1) {
            if (num > max) {
                scndmax = max;  // old max becomes second max
                max = num;      // update max
            } else if (num > scndmax && num != max) {
                scndmax = num;  // update only second max
            }
        }

        System.out.println("Largest element: " + max);
        System.out.println("Second largest element: " + scndmax);
                
     }

}
