public class FindMaxMinEle {
    public static void main(String[] args) {
        int arrayElements[]={32,65,75,23,54,-1,12};
        
        System.out.println("select option to perform the opeation");
        System.out.println("1 for Max Ele and 2 for Min Ele");
        System.out.println("-----------------------------");
        int optionSelected=2;
        switch (optionSelected) {
            case 1:
        int max=0;
        for(int i:arrayElements)
        {
            if(i>max)
            {
                max=i;
            }

        }
        System.out.println("Maximum ele is "+max);        
                break;
         case 2:
         int min=arrayElements[3];
         for(int i=0;i<arrayElements.length-1;i++)
         {
            if(arrayElements[i]<min)
            {
                min=arrayElements[i];
            }
         }
         System.out.println("minimum ele is "+min);

         break;
            default:
            System.out.println("invalid option selected");
                break;
        }
        
    }
}
