public class FrequencyEle {
    public static void main(String[] args) {
        int array1[]={12,4,5,23,23,24,46,4,2,3,3,23,64,64,46,64};
        int flag=-1;
        for (int i = 0; i < array1.length; i++) {
            int c=0;
            for (int j = i+1; j < array1.length; j++) {
                if(array1[i]==array1[j]&&array1[j]!=-1)
                {
                    array1[j]=-1;
                    c++;
                }
            }
            if(c>0)
            {
                System.out.println(array1[i]+" is Repeated::"+c);
            }
        }
    }
    
}
