public class CalcSumAvgEle {
     public static void main(String []args)
     {
        int arrayElements1[]={12,45,56,43,98,76,89,54,14,121};
          int sum=0;
        for (int i = 0; i < arrayElements1.length; i++) {
          System.out.println(arrayElements1[i]);
        sum=sum+arrayElements1[i];
     }
        int len=arrayElements1.length;
        System.out.println("Sum is ::"+sum+" & Average is ::"+(sum/len));
     }
}
