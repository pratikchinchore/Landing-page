

public class InsertEle {
        
    public static void main(String []args)
    {
        int array1[]=new int[21];  //declare var
     
        array1[0]=1;
        array1[1]=2;
        array1[2]=3;

         array1 =new int[]{21,43,54,24,54,76}; //redeclare and reintailze
        
         int array2[]={34,56,423,21,76,42,675};

         System.out.println("FOr each Loop  ");
         for (int i : array2) {
            System.out.println(i);           
         }
         System.out.println("for loop");
         for (int i = 0; i < array2.length; i++) {
            System.out.println(array2[i]);
         }

    }

}
