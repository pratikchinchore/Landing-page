public class SearchEleLiner {
    public static void main(String[] args) {
        int array1[]={12,34,56,7,6,89,56,247,56,9,8,87};
        int eleToSearch=56;
        for(int i=0;i<array1.length-1;i++)
        {
            if(eleToSearch==array1[i])
             {
                System.out.println("Ele found::"+array1[i]+" index at "+i);
                break;
             }       
        }
    }
}
