package Array.Intermediate;

public class BinarySearch {
    public static void main(String[] args) {
      int[] arr = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91}; // sorted array
        int target = 72;

        int left = 0;                 // first index
        int right = arr.length - 1;   // last index
        int mid;                      // middle index
        boolean found = false;        // flag

        while (left <= right) {
            mid = (left + right) / 2; // find the middle

            if (arr[mid] == target) {        // if found
                System.out.println("Found " + target + " at index " + mid);
                found = true;
                break;
            } else if (arr[mid] < target) {  // if target is bigger
                left = mid + 1;              // search right half
            } else {                         // if target is smaller
                right = mid - 1;             // search left half
            }
        }

        if (!found) {
            System.out.println("Element not found!");
        }
    }
}
