import java.util.*;
class GCDNumber{
    public static void main(String []args)
    {
        System.out.println("ENter the numer ");
        Scanner sc=new Scanner(System.in);
        int inputNUmber=sc.nextInt();
        int greaterNum=0;
        for(int i=1;i<=inputNUmber;i++)
        {
            if(inputNUmber%i==0)
            {
                if(i!=inputNUmber)
                {
                    System.out.println(" "+i);
                    greaterNum=i;
                }
            }
        }
        System.out.println("Greater number we have is "+greaterNum);

    }
}