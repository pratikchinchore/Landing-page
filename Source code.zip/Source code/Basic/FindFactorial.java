import java.util.*;

class FindFactorial{

    public static void main(String[] args)
    {
        Scanner scn=new Scanner(System.in);
        System.out.println("ENter the Number ");
        int number=scn.nextInt();
        
        int factorialNumber=1;
        for(int i=number;i>=1;i--)
        {
            factorialNumber=factorialNumber*i;
        }

        System.out.println("fact"+factorialNumber);
    }
}